<?php


echo "primeira aula variavel <br>";

$variavel =1;
$variaveldois =2;

echo "variavel um boas vindas {$variavel} <br>";
echo "variavel dois continuação {$variaveldois} <br>";
echo 'variavel um boas vindas {$variavel} <br>';
echo 'variavel dois continuação {$variaveldois} <br>';

$nome ="Danilo";
$nomedois = "Ana";

echo "olá sr. {$nome} <br>";
echo "olá sra. {$nomedois} <br>";

$variavelconcat =$nome . " " .$nomedois;



echo $variavelconcat . "<br>";

$variavel3 = $variavel + $variaveldois ;

echo $variavel3 . "<br>";



