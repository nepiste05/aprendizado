<?php

// desafio 1
$nome ="Ana";
$sobrenome ="Claudia";
$nomeCompleto = $nome . " ". $sobrenome;
echo "Nome completo: " . $nomeCompleto . "<br>";


// desafio 2
$numero1 = 20;
$numero2 = 12;
$somaInteiros = $numero1 + $numero2;
echo "Soma de inteiros: " . $somaInteiros . "<br>";

$resultadoDivisao = $numero1 / $numero2;
echo "O resultado da divisão é: " . $resultadoDivisao . "<br>";

$resultadoSubtracao = $numero1 - $numero2;
echo "O resultado da subtração é: " . $resultadoSubtracao . "<br>";

$resultadoMultiplicacao = $numero1 * $numero2;
echo "O resultado da multiplicação é: " . $resultadoMultiplicacao . "<br>";

// desafio 3


$numeroFloat = 3.23;
$numeroDouble = 2.495694;
$somaFloatDouble = $numeroFloat + $numeroDouble;
echo "Soma de float e double: " . $somaFloatDouble . "<br>";

// desafio 5
$variavelconcat =$nome . " " .$sobrenome . " " .$numero1 . " " .$numero2 . "<br>";
echo $variavelConcat = "<br>";
$variavel3 = $nome . ' ' . $sobrenome . ' ' . ($numero1 + $numero2);
echo $variavel3 . "<br>";


